package com.nammakovai.nammakovai.utils;

import java.io.Serializable;
import java.util.ArrayList;

public class objCreation implements Serializable {
private ArrayList<String> plcList;
private ArrayList<String> locList;
private ArrayList<String> imgList;
private ArrayList<String> contList;
public ArrayList<String> getPlcList() {
	return plcList;
}
public void setPlcList(ArrayList<String> plcList) {
	this.plcList = plcList;
}
public ArrayList<String> getLocList() {
	return locList;
}
public void setLocList(ArrayList<String> locList) {
	this.locList = locList;
}
public ArrayList<String> getContList() {
	return contList;
}
public void setContList(ArrayList<String> contList) {
	this.contList = contList;
}
public ArrayList<String> getImgList() {
	return imgList;
}
public void setImgList(ArrayList<String> imgList) {
	this.imgList = imgList;
}


}
