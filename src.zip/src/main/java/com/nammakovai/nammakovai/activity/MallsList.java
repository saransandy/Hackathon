package com.nammakovai.nammakovai.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.nammakovai.nammakovai.utils.objCreation;

import java.util.ArrayList;

public class MallsList extends AppCompatActivity {


    ArrayList<String> malls;
    ArrayList<String> location;
    ArrayList<String> content;
    ArrayList<String> image;
    objCreation obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
      /*   setContentView(R.layout.activity_malls_list);*/

        malls = new ArrayList<String>();
        location = new ArrayList<String>();
        content = new ArrayList<String>();
        image = new ArrayList<String>();

        obj = new objCreation();

        malls.add("Brookefields Mall");
        malls.add("Fun Republic Mall ");
        malls.add("Prozone Mall");

        location.add("https://www.google.co.in/maps/dir/''/Brookefields+Mall,+Dr+Krishnasamy+mudaliyar+Road,+Coimbatore,+Tamil+Nadu+641001/@11.0094689,76.8892077,12z/data=!3m1!4b1!4m8!4m7!1m0!1m5!1m1!1s0x3ba859015dcbbe93:0x48ced40a587ca58e!2m2!1d76.9592483!2d11.0094769");
        location.add("https://www.google.co.in/maps/dir/''/Fun+Republic+Mall+Peelamedu,+Avinashi+Road,+Peelamedu,+Coimbatore,+Tamil+Nadu+641004/@11.0243753,76.9407365,12z/data=!3m1!4b1!4m8!4m7!1m0!1m5!1m1!1s0x3ba857808ae76bb5:0xc3c0586384052a74!2m2!1d77.0107771!2d11.0243833");
        location.add("https://www.google.co.in/maps/dir/''/Prozone+Mall,+National+Highway+209,+Sivanandhapuram,+Coimbatore,+Tamil+Nadu+641035/@11.0551428,76.9240288,12z/data=!3m1!4b1!4m8!4m7!1m0!1m5!1m1!1s0x3ba85809422410f5:0xfc5f01d16530ec4!2m2!1d76.9940694!2d11.0551509");

        content.add("Brookefields is a shopping mall located on Brookebond Road (Krishnasamy Road).The mall has outlets from major clothing and apparel brands and a six screen multiplex cinema, along with a food court serving multi-cuisine dishes.");
        content.add("Fun Republic Mall is a shopping mall in Peelamedu, Coimbatore, India.The mall features a five screen multiplex operated by Fun Cinemas with a capacity of 1,119 seats, and a McDonalds restaurant spread over 3,470 sq. ft on two floors in addition to its food court.");
        content.add("Prozone CSC is likely to launch its shopping mall project in Coimbatore this year. Nigam Patel, director of Prozone CSC, told The Hindu here on Tuesday that the mall is planned as part of a mixed use development on Saravanampatty Road. The company proposes to develop shopping, entertainment, commercial, and residential projects on 25 acres.");
        image.add("brooke");
        image.add("fun");
        image.add("prozone");

        obj.setPlcList(malls);
        obj.setLocList(location);
        obj.setContList(content);
        obj.setImgList(image);

        Intent next = new Intent(this,placesLoc.class);
        next.putExtra("plobj", obj);
        startActivity(next);
    }
}
