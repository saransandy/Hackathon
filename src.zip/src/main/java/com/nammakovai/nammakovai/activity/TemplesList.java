package com.nammakovai.nammakovai.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.nammakovai.nammakovai.utils.objCreation;

import java.util.ArrayList;

public class TemplesList extends AppCompatActivity {

    ArrayList<String> temples;
    ArrayList<String> location;
    ArrayList<String> image;
    ArrayList<String> content;
    objCreation obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       /* setContentView(R.layout.activity_temples_list);
*/
        temples = new ArrayList<String>();
        location = new ArrayList<String>();
        image = new ArrayList<String>();
        //List<Byte> arrays = new ArrayList<Byte>();
        content = new ArrayList<String>();
        obj = new objCreation();

        temples.add("Amer Fort");
        temples.add("Hawa Mahal");
        temples.add("Jal Mahal");
        temples.add("Jaigarh Fort");
        temples.add("City Palace");
        temples.add("Jantar Mantar");
        temples.add("Nahargarh Fort");


        location.add("https://www.google.co.in/maps/place/Amber+Palace/@26.9613313,75.8157661,14z/data=!4m8!1m2!2m1!1sfort+in+jaipur!3m4!1s0x396db05acbd20dfb:0x6221df6747147e2b!8m2!3d26.9854865!4d75.8513454");
        location.add("https://www.google.co.in/maps/place/Hawa+Mahal/@26.9237841,75.8267139,17z/data=!4m12!1m6!3m5!1s0x396db14b1bd30ba5:0x860e5d531eccb20c!2sHawa+Mahal!8m2!3d26.9239363!4d75.8267438!3m4!1s0x396db14b1bd30ba5:0x860e5d531eccb20c!8m2!3d26.9239363!4d75.8267438");
        location.add("https://www.google.co.in/maps/place/Jal+Mahal/@26.9534682,75.8439493,17z/data=!3m1!4b1!4m5!3m4!1s0x396db11be9767295:0x97d34f11a313abd2!8m2!3d26.9534306!4d75.8460746");
        location.add("https://www.google.co.in/maps/place/Jaigarh+Fort/@26.9613291,75.8157661,14z/data=!4m8!1m2!2m1!1sfort+in+jaipur!3m4!1s0x396db1b1b15f49c7:0xbc19c49ec4a15381!8m2!3d26.9850877!4d75.8455928");
        location.add("https://www.google.co.in/maps/place/City+Palace/@26.9257713,75.8214694,17z/data=!3m1!4b1!4m5!3m4!1s0x396db40b8620b0c1:0x44801531017d7b60!8m2!3d26.9257713!4d75.8236581");
        location.add("https://www.google.co.in/maps/place/Jantar+Mantar/@28.6270547,77.214438,17z/data=!3m1!4b1!4m5!3m4!1s0x390cfd4a694fc49b:0xa24a6ec962781b0c!8m2!3d28.6270547!4d77.2166267");
        location.add("https://www.google.co.in/maps/place/Nahargarh+Fort/@26.9613291,75.8157661,14z/data=!4m8!1m2!2m1!1sfort+in+jaipur!3m4!1s0x396db15cf347f3d1:0xaaaa6e617ae9e8b!8m2!3d26.9371782!4d75.815206");
        //start
		/*Bitmap bmp = BitmapFactory.decodeResource(getResources(), R.drawable.maruthamalaitemple);
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
		byte[] byteArray = stream.toByteArray();*/
        //end
        //arrays.add(byteArray);

        image.add("amberfortjaipur");
        image.add("hawamahal");
        image.add("jalmahal");
        image.add("jaigarhfort");
        image.add("citypalace");
        image.add("jantar antar");
        image.add("nahargarhfort");

        content.add("Amer Fort is a fort located in Amer, Rajasthan, India. Amer is a town with an area of 4 square kilometres located 11 kilometres from Jaipur, the capital of Rajasthan. Located high on a hill, it is the principal tourist attraction in Jaipur.");
        content.add("built in 1799, by Maharaja Sawai Pratap Singh, is the most recognizable monument of Jaipur. The 5 storied stunning semioctagonal monument having 152 windows with over hanging latticed balconies is a fine piece of Rajput architecture. Originally designed for the royal ladies to watch and enjoy the processions and other activities, on the street below. Now it houses a well laid out museum. The display “Jaipur past and present” is the special feature of this newly setup museum.");
        content.add("Jal Mahal is a palace in the middle of the Man Sagar Lake in Jaipur city, the capital of the state of Rajasthan, India. The palace and the lake around it were renovated and enlarged in the 18th century by Maharaja Jai Singh II of Amber.");
        content.add("Jaigarh Fort is situated on the promontory called the Cheel ka Teela of the Aravalli range; it overlooks the Amber Fort and the Maota Lake, near Amber in Jaipur, Rajasthan, India.The world’s biggest cannon on wheels- the Jai Ban is positioned here, built during reign of Maharaja Sawai Jaisingh. It has a twenty feet long barrel and pumped in the cannon for a single shot.");
        content.add("City Palace, Jaipur, which includes the Chandra Mahal and Mubarak Mahal palaces and other buildings, is a palace complex in Jaipur, the capital of the Rajasthan state, India.");
        content.add("The Jantar Mantar monument in Jaipur, Rajasthan is a collection of nineteen architectural astronomical instruments, built by the Rajput king Sawai Jai Singh II, and completed in 1734.");
        content.add("Nahargarh Fort stands on the edge of the Aravalli Hills, overlooking the city of Jaipur in the Indian state of Rajasthan. Along with Amer Fort and Jaigarh Fort, Nahargarh once formed a strong defense ring for the city.");
        obj.setPlcList(temples);
        obj.setLocList(location);
        obj.setContList(content);
        obj.setImgList(image);

        Intent next = new Intent(this,placesLoc.class);
        next.putExtra("plobj", obj);
        startActivity(next);
    }
}
