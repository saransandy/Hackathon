package com.nammakovai.nammakovai.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.nammakovai.nammakovai.utils.objCreation;

import java.util.ArrayList;

public class HotelsList extends AppCompatActivity {


    ArrayList<String> hotels;
    ArrayList<String> location;
    ArrayList<String> content;
    ArrayList<String> image;

    objCreation obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       /* setContentView(R.layout.activity_hotels_list);
*/
        //setContentView(R.layout.activity_main);

        //Intialize new array
        hotels = new ArrayList<String>();
        location = new ArrayList<String>();
        content = new ArrayList<String>();
        image = new ArrayList<String>();

        obj = new objCreation();

        hotels.add("The Residency Hotel");
        hotels.add("Vivanta by Taj");
        hotels.add("Hotel Heritage Inn");
        hotels.add("The Residency Hotel");
        hotels.add("Vivanta by Taj");
        hotels.add("Hotel Heritage Inn");
        hotels.add("The Residency Hotel");
        hotels.add("Vivanta by Taj");
        hotels.add("Hotel Heritage Inn");

        location.add("https://www.google.co.in/maps/place/The+Residency+Hotel/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sHotels+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");
        location.add("https://www.google.co.in/maps/place/Vivanta+by+Taj+-+Surya/@11.0184723,76.9671801,13z/data=!4m8!1m2!2m1!1sHotels+in+coimbatore!3m4!1s0x0:0x59758803dbf21a64!8m2!3d11.002279!4d76.973516");
        location.add("https://www.google.co.in/maps/place/Hotel+Heritage+Inn/@11.0184723,76.9671801,13z/data=!4m8!1m2!2m1!1sHotels+in+coimbatore!3m4!1s0x3ba859aa52213c51:0xa62ff557f2ea2617!8m2!3d11.0104511!4d76.9668726");
        location.add("https://www.google.co.in/maps/place/The+Residency+Hotel/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sHotels+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");
        location.add("https://www.google.co.in/maps/place/Vivanta+by+Taj+-+Surya/@11.0184723,76.9671801,13z/data=!4m8!1m2!2m1!1sHotels+in+coimbatore!3m4!1s0x0:0x59758803dbf21a64!8m2!3d11.002279!4d76.973516");
        location.add("https://www.google.co.in/maps/place/Hotel+Heritage+Inn/@11.0184723,76.9671801,13z/data=!4m8!1m2!2m1!1sHotels+in+coimbatore!3m4!1s0x3ba859aa52213c51:0xa62ff557f2ea2617!8m2!3d11.0104511!4d76.9668726");
        location.add("https://www.google.co.in/maps/place/The+Residency+Hotel/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sHotels+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");
        location.add("https://www.google.co.in/maps/place/Vivanta+by+Taj+-+Surya/@11.0184723,76.9671801,13z/data=!4m8!1m2!2m1!1sHotels+in+coimbatore!3m4!1s0x0:0x59758803dbf21a64!8m2!3d11.002279!4d76.973516");
        location.add("https://www.google.co.in/maps/place/Hotel+Heritage+Inn/@11.0184723,76.9671801,13z/data=!4m8!1m2!2m1!1sHotels+in+coimbatore!3m4!1s0x3ba859aa52213c51:0xa62ff557f2ea2617!8m2!3d11.0104511!4d76.9668726");


        content.add("This luxe hotel is an 11-minute walk from G. D. Naidu Industrial Exhibition.Featuring modern furnishings and wood or marble floors, the simple rooms have free Wi-Fi, flat-screen TVs, minibars and tea and coffeemaking equipment. Suites feature living and dining rooms.");
        content.add("This upscale hotel in a modern block building is a 15-minute walk from Jawaharlal Nehru Stadium.The airy, modern rooms have Wi-Fi (fee), flat-screens, minibars, and tea and coffeemaking equipment. Upgraded rooms add airy terraces and access to the loung.");
        content.add("This straightforward hotel is a 9-minute walk from VOC Park.The modern rooms with wood floors and minimalist furnishings also feature free Wi-Fi, flat-screen TVs and minibars. There's 24-hour room service.");
        content.add("This luxe hotel is an 11-minute walk from G. D. Naidu Industrial Exhibition.Featuring modern furnishings and wood or marble floors, the simple rooms have free Wi-Fi, flat-screen TVs, minibars and tea and coffeemaking equipment. Suites feature living and dining rooms.");
        content.add("This upscale hotel in a modern block building is a 15-minute walk from Jawaharlal Nehru Stadium.The airy, modern rooms have Wi-Fi (fee), flat-screens, minibars, and tea and coffeemaking equipment. Upgraded rooms add airy terraces and access to the loung.");
        content.add("This straightforward hotel is a 9-minute walk from VOC Park.The modern rooms with wood floors and minimalist furnishings also feature free Wi-Fi, flat-screen TVs and minibars. There's 24-hour room service.");
        content.add("This luxe hotel is an 11-minute walk from G. D. Naidu Industrial Exhibition.Featuring modern furnishings and wood or marble floors, the simple rooms have free Wi-Fi, flat-screen TVs, minibars and tea and coffeemaking equipment. Suites feature living and dining rooms.");
        content.add("This upscale hotel in a modern block building is a 15-minute walk from Jawaharlal Nehru Stadium.The airy, modern rooms have Wi-Fi (fee), flat-screens, minibars, and tea and coffeemaking equipment. Upgraded rooms add airy terraces and access to the loung.");
        content.add("This straightforward hotel is a 9-minute walk from VOC Park.The modern rooms with wood floors and minimalist furnishings also feature free Wi-Fi, flat-screen TVs and minibars. There's 24-hour room service.");

        image.add("kmch");
        image.add("vivantha");
        image.add("heritage");
        image.add("kmch");
        image.add("vivantha");
        image.add("heritage");
        image.add("kmch");
        image.add("vivantha");
        image.add("heritage");

        obj.setPlcList(hotels);
        obj.setLocList(location);
        obj.setContList(content);
        obj.setImgList(image);


        Intent next = new Intent(this,placesLoc.class);
        next.putExtra("plobj", obj);
        startActivity(next);
    }
}
