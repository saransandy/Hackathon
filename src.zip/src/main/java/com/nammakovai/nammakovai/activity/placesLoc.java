package com.nammakovai.nammakovai.activity;

import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.nammakovai.nammakovai.R;
import com.nammakovai.nammakovai.utils.objCreation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static android.support.v7.appcompat.R.attr.selectableItemBackground;

public class placesLoc extends AppCompatActivity implements AdapterView.OnItemClickListener {


    objCreation plobject;
    ArrayList<String> plaArray;
    ArrayList<String> locArray;
    ArrayList<String> conArray;
    ArrayList<String> imgArray;
    String[] locationArray;
    String[] placeArray;
    String[] contentArray;
    String[] imageArray;
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
        setContentView(R.layout.activity_places_loc);

        lv = (ListView)findViewById(R.id.listView1);
        Intent int_placeLoc = getIntent();
        plobject = (objCreation)int_placeLoc.getSerializableExtra("plobj");
        plaArray = plobject.getPlcList();
        locArray = plobject.getLocList();
        conArray = plobject.getContList();
        imgArray = plobject.getImgList();
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        locationArray = locArray.toArray(new String[locArray.size()]);
        placeArray = plaArray.toArray(new String[plaArray.size()]);
        contentArray = conArray.toArray(new String[conArray.size()]);
        imageArray = imgArray.toArray(new String[imgArray.size()]);
        //ArrayAdapter<String> ada = new ArrayAdapter<String>(this,android.R.layout.simple_expandable_list_item_2,android.R.id.text2, plaArray);
			/*MySimpleArrayAdapter adapter = new MySimpleArrayAdapter(this, placeArray);
            lv.setAdapter(adapter);
			*///lv.setAdapter(ada);

        // Create a List from String Array elements
        final List<String> fruits_list = new ArrayList<String>(Arrays.asList(placeArray));

        // Create an ArrayAdapter from List
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, fruits_list){
            @Override
            public View getView(int position, View convertView, ViewGroup parent){
                // Get the current item from ListView
                View view = super.getView(position,convertView,parent);

                Typeface tv = Typeface.createFromAsset(getAssets(),"DroidSans.ttf");
                ((TextView) view).setTypeface(tv);
                ((TextView) view).setTextColor(Color.parseColor("#000000"));
                //if(position %2 == 1)
                //{
                // Set a background color for ListView regular row/item
                //view.setBackgroundColor(Color.parseColor("#FFB6B546"));
                view.setBackgroundColor(Color.parseColor("#ffffff"));

                int[] attrs = new int[] { android.R.attr.selectableItemBackground /* index 0 */};

                // Obtain the styled attributes. 'themedContext' is a context with a
                // theme, typically the current Activity (i.e. 'this')
                TypedArray ta = obtainStyledAttributes(attrs);

                // Now get the value of the 'listItemBackground' attribute that was
                // set in the theme used in 'themedContext'. The parameter is the index
                // of the attribute in the 'attrs' array. The returned Drawable
                // is what you are after
                Drawable drawableFromTheme = ta.getDrawable(0 /* index */);

                // Finally free resources used by TypedArray
                ta.recycle();
                view.setBackground(drawableFromTheme);
                //}
                //else
                //{
                // Set the background color for alternate row/item
                //view.setBackgroundColor(Color.parseColor("#FFCCCB4C"));
                //	view.setBackgroundColor(Color.parseColor("#423d3d"));
                //}
                return view;
            }
        };

        lv.setAdapter(arrayAdapter);
        lv.setOnItemClickListener(this);

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position,
                            long id) {
        // TODO Auto-generated method stub
        Intent mapLoc = new Intent(getApplicationContext(),MapLocation.class);
        mapLoc.putExtra("location", locationArray[position]);
        mapLoc.putExtra("name", placeArray[position]);
        mapLoc.putExtra("content", contentArray[position]);
        mapLoc.putExtra("image", imageArray[position]);
        startActivity(mapLoc);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        // your code.
        Intent back = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(back);
    }
}
