package com.nammakovai.nammakovai.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

import com.nammakovai.nammakovai.R;

public class WebViews extends AppCompatActivity {

    WebView webviews;
    String location;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
        setContentView(R.layout.activity_web_views);

        webviews = (WebView)findViewById(R.id.webView1);
        Intent web = getIntent();

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if(extras == null) {
                location= null;
            } else {
                location= extras.getString("location");
            }
        } else {
            location= (String) savedInstanceState.getSerializable("location");
        }
        webviews.loadUrl(location);
    }
}
