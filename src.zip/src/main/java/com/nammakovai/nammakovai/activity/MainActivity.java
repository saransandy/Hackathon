package com.nammakovai.nammakovai.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.nammakovai.nammakovai.R;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, BaseSliderView.OnSliderClickListener {


    CardView imgbtn_tmpl;
    CardView imgbtn_hosp;
    CardView imgbtn_hotl;
    CardView imgbtn_mall;
    CardView imgbtn_ehop;
    CardView imgbtn_epol;

    private SliderLayout mDemoSlider;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
        setContentView(R.layout.activity_main);

        //Get their views
        imgbtn_tmpl = (CardView)findViewById(R.id.button1);
        imgbtn_hosp = (CardView)findViewById(R.id.button2);
        imgbtn_hotl = (CardView)findViewById(R.id.button3);
        imgbtn_mall = (CardView)findViewById(R.id.button4);
        imgbtn_ehop = (CardView)findViewById(R.id.button5);
        imgbtn_epol = (CardView)findViewById(R.id.button6);

        //SetListeners for all buttons
        imgbtn_tmpl.setOnClickListener(this);
        imgbtn_hosp.setOnClickListener(this);
        imgbtn_hotl.setOnClickListener(this);
        imgbtn_mall.setOnClickListener(this);
        imgbtn_ehop.setOnClickListener(this);
        imgbtn_epol.setOnClickListener(this);

        mDemoSlider = (SliderLayout)findViewById(R.id.slider);

        HashMap<String,Integer> file_maps = new HashMap<String, Integer>();
        file_maps.put("Hannibal",R.drawable.slider_1);
        file_maps.put("Big Bang Theory",R.drawable.slider_2);
        file_maps.put("House of Cards",R.drawable.slider_3);
        file_maps.put("Game of Thrones", R.drawable.slider_4);
        file_maps.put("Game of Thrones", R.drawable.slider_5);
        file_maps.put("Game of Thrones", R.drawable.slider_6);

        for(String name : file_maps.keySet()){
            TextSliderView textSliderView = new TextSliderView(this);
            // initialize a SliderLayout
            textSliderView

                    .image(file_maps.get(name))
                    .setScaleType(BaseSliderView.ScaleType.Fit)
                    .setOnSliderClickListener(this);

            //add your extra information
           /* textSliderView.bundle(new Bundle());
            textSliderView.getBundle()
                    .putString("extra",name);
*/
            mDemoSlider.addSlider(textSliderView);
        }

        mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Accordion);
        mDemoSlider.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
        mDemoSlider.setCustomAnimation(new DescriptionAnimation());
        mDemoSlider.setDuration(4000);

    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch(v.getId()){
            case R.id.button1:
                Intent int_tmpl = new Intent(getApplicationContext(),TemplesList.class);
                startActivity(int_tmpl);
                break;
            case R.id.button2:
                Intent int_hosp = new Intent(getApplicationContext(),HospitalsList.class);
                startActivity(int_hosp);
                break;
            case R.id.button3:
                Intent int_hotl = new Intent(getApplicationContext(),HotelsList.class);
                startActivity(int_hotl);
                break;
            case R.id.button4:
                Intent int_mall = new Intent(getApplicationContext(),MallsList.class);
                startActivity(int_mall);
                break;
            case R.id.button5:
                Intent int_ehop = new Intent(getApplicationContext(),EmgcyHospital.class);
                startActivity(int_ehop);
                break;
            case R.id.button6:
                Intent int_epol = new Intent(getApplicationContext(),EmgcyPolice.class);
                startActivity(int_epol);
                break;
        }

    }
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);//***Change Here***
        startActivity(intent);
        finish();
        System.exit(0);
    }

    @Override
    public void onSliderClick(BaseSliderView slider) {

        Intent int_tmpl = new Intent(getApplicationContext(),tourList.class);
        startActivity(int_tmpl);

    }
}
