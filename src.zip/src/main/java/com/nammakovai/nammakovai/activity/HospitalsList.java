package com.nammakovai.nammakovai.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.nammakovai.nammakovai.utils.objCreation;

import java.util.ArrayList;

public class HospitalsList extends AppCompatActivity {

    ArrayList<String> hospitals;
    ArrayList<String> location;
    ArrayList<String> content;
    ArrayList<String> image;


    objCreation obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);

       /*  setContentView(R.layout.activity_hospitals_list);*/

        hospitals = new ArrayList<String>();
        location = new ArrayList<String>();
        content = new ArrayList<String>();
        image = new ArrayList<String>();
        obj = new objCreation();

        hospitals.add("Imperial Hospital ");
        hospitals.add("Vedanta Superspeciality Hospital ");
        hospitals.add("Apex Hospital ");
        hospitals.add("Bansal Hospital & Research Centre ");
        hospitals.add("Cocoon Hospital ");
        hospitals.add("Santokba Durlabhji Memorial Hospital & Medical Research Institute ");
        hospitals.add("Babylon Children Hospital ");
        hospitals.add("Global Heart & General Hospital ");
        hospitals.add("KDG medical and dental centre");
        hospitals.add("Krati Dental Care ");
        hospitals.add("Pushpanjali Dental Clinic ");
        hospitals.add("Saket Hospital ");


        location.add("https://www.google.co.in/maps/place/Kovai+Medical+Center+and+Hospital/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba857c6e0aac7c7:0x6ca8e27472a4a8bc!8m2!3d11.0420864!4d77.0403253");
        location.add("https://www.google.co.in/maps/place/PSG+Hospitals/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba859030ea11999:0xe4e7cf2ff5b622d9!8m2!3d11.0212261!4d77.0108249");
        location.add("https://www.google.co.in/maps/place/Sri+Ramakrishna+Hospital/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba8584fc402bb03:0x297f278e04611061!8m2!3d11.023687!4d76.976715");
        location.add("https://www.google.co.in/maps/place/Kovai+Medical+Center+and+Hospital/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba857c6e0aac7c7:0x6ca8e27472a4a8bc!8m2!3d11.0420864!4d77.0403253");
        location.add("https://www.google.co.in/maps/place/PSG+Hospitals/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba859030ea11999:0xe4e7cf2ff5b622d9!8m2!3d11.0212261!4d77.0108249");
        location.add("https://www.google.co.in/maps/place/Sri+Ramakrishna+Hospital/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba8584fc402bb03:0x297f278e04611061!8m2!3d11.023687!4d76.976715");
        location.add("https://www.google.co.in/maps/place/Kovai+Medical+Center+and+Hospital/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba857c6e0aac7c7:0x6ca8e27472a4a8bc!8m2!3d11.0420864!4d77.0403253");
        location.add("https://www.google.co.in/maps/place/PSG+Hospitals/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba859030ea11999:0xe4e7cf2ff5b622d9!8m2!3d11.0212261!4d77.0108249");
        location.add("https://www.google.co.in/maps/place/Sri+Ramakrishna+Hospital/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba8584fc402bb03:0x297f278e04611061!8m2!3d11.023687!4d76.976715");
        location.add("https://www.google.co.in/maps/place/Kovai+Medical+Center+and+Hospital/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba857c6e0aac7c7:0x6ca8e27472a4a8bc!8m2!3d11.0420864!4d77.0403253");
        location.add("https://www.google.co.in/maps/place/PSG+Hospitals/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba859030ea11999:0xe4e7cf2ff5b622d9!8m2!3d11.0212261!4d77.0108249");
        location.add("https://www.google.co.in/maps/place/Sri+Ramakrishna+Hospital/@11.0188013,76.9668366,13z/data=!4m8!1m2!2m1!1shospitals+in+coimbatore!3m4!1s0x3ba8584fc402bb03:0x297f278e04611061!8m2!3d11.023687!4d76.976715");

        content.add("KMCH is the most trusted Multispecialty Hospital in the Southern Indian City of Coimbatore.The relentless service of KMCH in the past 26 years, taken health care to the most modern levels in the region catering to urban and rural population.");
        content.add("Established in the year 1989, PSG Hospitals has been rendering patient-centric medical service with more than 1000 beds. Coimbatore, being one of the largest medical tourist centers in India, PSG Hospitals offers a wide range of specialist health care services for people from India and abroad.");
        content.add("Sri Ramakrishna Hospital with 750 beds having state-of-the-art medical equipment’s for diagnostic and treatment facilities with well qualified and experienced doctors. Free medical treatment is provided to the needy patients in the Hospital. Concessions in the treatment charges are given to those who cannot afford the full cost of treatment.");
        content.add("KMCH is the most trusted Multispecialty Hospital in the Southern Indian City of Coimbatore.The relentless service of KMCH in the past 26 years, taken health care to the most modern levels in the region catering to urban and rural population.");
        content.add("Established in the year 1989, PSG Hospitals has been rendering patient-centric medical service with more than 1000 beds. Coimbatore, being one of the largest medical tourist centers in India, PSG Hospitals offers a wide range of specialist health care services for people from India and abroad.");
        content.add("Sri Ramakrishna Hospital with 750 beds having state-of-the-art medical equipment’s for diagnostic and treatment facilities with well qualified and experienced doctors. Free medical treatment is provided to the needy patients in the Hospital. Concessions in the treatment charges are given to those who cannot afford the full cost of treatment.");
        content.add("KMCH is the most trusted Multispecialty Hospital in the Southern Indian City of Coimbatore.The relentless service of KMCH in the past 26 years, taken health care to the most modern levels in the region catering to urban and rural population.");
        content.add("Established in the year 1989, PSG Hospitals has been rendering patient-centric medical service with more than 1000 beds. Coimbatore, being one of the largest medical tourist centers in India, PSG Hospitals offers a wide range of specialist health care services for people from India and abroad.");
        content.add("Sri Ramakrishna Hospital with 750 beds having state-of-the-art medical equipment’s for diagnostic and treatment facilities with well qualified and experienced doctors. Free medical treatment is provided to the needy patients in the Hospital. Concessions in the treatment charges are given to those who cannot afford the full cost of treatment.");
        content.add("KMCH is the most trusted Multispecialty Hospital in the Southern Indian City of Coimbatore.The relentless service of KMCH in the past 26 years, taken health care to the most modern levels in the region catering to urban and rural population.");
        content.add("Established in the year 1989, PSG Hospitals has been rendering patient-centric medical service with more than 1000 beds. Coimbatore, being one of the largest medical tourist centers in India, PSG Hospitals offers a wide range of specialist health care services for people from India and abroad.");
        content.add("Sri Ramakrishna Hospital with 750 beds having state-of-the-art medical equipment’s for diagnostic and treatment facilities with well qualified and experienced doctors. Free medical treatment is provided to the needy patients in the Hospital. Concessions in the treatment charges are given to those who cannot afford the full cost of treatment.");

        image.add("kmch");
        image.add("psg");
        image.add("srk");
        image.add("kmch");
        image.add("psg");
        image.add("srk");
        image.add("kmch");
        image.add("psg");
        image.add("srk");
        image.add("kmch");
        image.add("psg");
        image.add("srk");

        obj.setPlcList(hospitals);
        obj.setLocList(location);
        obj.setContList(content);
        obj.setImgList(image);

        Intent next = new Intent(this,placesLoc.class);
        next.putExtra("plobj", obj);
        startActivity(next);
    }
}
