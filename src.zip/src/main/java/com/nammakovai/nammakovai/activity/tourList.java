package com.nammakovai.nammakovai.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.nammakovai.nammakovai.R;
import com.nammakovai.nammakovai.utils.objCreation;

import java.util.ArrayList;

public class tourList extends AppCompatActivity {

    ArrayList<String> hotels;
    ArrayList<String> location;
    ArrayList<String> content;
    ArrayList<String> image;
    objCreation obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_tour_list);

        //Intialize new array
        hotels = new ArrayList<String>();
        location = new ArrayList<String>();
        content = new ArrayList<String>();
        image = new ArrayList<String>();

        obj = new objCreation();

        hotels.add("Azhiyar Dam");
        hotels.add("Black Thunder");
        hotels.add("Kodiveri Dam");
        hotels.add("Kovai Kondattam");
        hotels.add("Mudhumalai Tiger Reserve");
        hotels.add("Siruvani Dam");
        hotels.add("Thirumoorthy Hills");
        hotels.add("Vaidheyi Falls");
        hotels.add("Vaalparai");


        location.add("https://www.google.co.in/maps/place/Azhiyar+Dam/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sTourPlaces+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");
        location.add("https://www.google.co.in/maps/place/Black+thunder/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sTourPlaces+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");
        location.add("https://www.google.co.in/maps/place/Kodiveri+dam/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sTourPlaces+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");
        location.add("https://www.google.co.in/maps/place/Kovai+kondatam/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sTourPlaces+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");
        location.add("https://www.google.co.in/maps/place/Mudhumalai+tiger+reserve/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sTourPlaces+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");
        location.add("https://www.google.co.in/maps/place/siruvani+dam/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sTourPlaces+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");
        location.add("https://www.google.co.in/maps/place/thirumoorthy+hills/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sTourPlaces+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");
        location.add("https://www.google.co.in/maps/place/vaidheyi+falls/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sTourPlaces+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");
        location.add("https://www.google.co.in/maps/place/vaalparai/@11.0183078,76.9673518,13z/data=!4m8!1m2!2m1!1sTourPlaces+in+coimbatore!3m4!1s0x0:0x8de8ead449244039!8m2!3d11.0102575!4d76.9804176");

        content.add("Aliyar (ஆழியாறு)  Reservoir is a 6.48 km (2.5 sq mi) reservoir located in Aliyar village near Pollachi town in Coimbatore District, Tamil Nadu, South India. The dam is located in the foothills of valparai, in the Anaimalai Hills of the Western Ghats. It is about 65 kilometers (40 mi) from Coimbatore. The dam offers some ideal getaways including a park, garden, aquarium, play area and a mini Theme-Park maintained by Tamil Nadu Fisheries Corporation for visitors enjoyment. The scenery is beautiful, with mountains surrounding three quarters of the reservoir. Boating is also available.\n");
        content.add("Black Thunder is a water theme park located in Tamil Nadu, India. It is situated at the foot of Nilgiris near Mettupalayam, in Coimbatore 40 km north of the city and occupies an area of about 75 acres (300,000 m2). The park offers about 49 rides, Surf Hill and the Wild River Ride notable among them. The park has a hotel situated within its premises.\n");
        content.add("Kodiveri Dam is located on the Bhavani river near Gobichettipalayam in Western Tamil Nadu. The dam is situated along the State Highway 15 about 15 km (9.3 mi) from Gobichettipalayam towards Sathyamangalam. It was constructed by Kongalvan in the year 1125 AD. Creating the dam consisted of carving a 20-foot wall of rock. The stones were then interlocked with iron bars and lead was used as mortar. These features, however, are not visible except in the dry season when the water level in the river drops considerably.\n    ");
        content.add("Kovai Kuttralam is a scenic spot with a gentle waterfall originating on the Siruvani hill ranges. It is located on the western ghat mountain range that lies to the west of this city at a distance of about 35 kms from Coimbatore. The siruvani dam is just above this water fall and this place is under the control of forest department. Permission has to be sought from them to visit this Kovai Kuttralam Falls. Limited bus service is available from the city and this area is out of bounds after 5 pm. This is the only place near Coimbatore where you find a nice enchanting waterfall.");
        content.add("The Mudhumalai National Park and Wildlife Sanctuary (Tamil:முதுமலை தேசிய பூங்கா மற்றும் விலங்குகள் சரணாலயம்) also a declared tiger reserve, lies on the northwestern side of the Nilgiris Hills (Blue Mountains), in Nilgiris, about 150 kilometers (93 mi) north-west of Coimbatore city in Kongu Nadu region of Tamil Nadu. It shares its boundaries with the states of Karnataka and Kerala. The sanctuary is divided into five ranges – Masinagudi, Thepakadu, Mudhumalai, Kargudi and Nellakota.  The protected area is home to several endangered and vulnerable species including Indian elephant, Bengal tiger, gaur and Indian leopard. There are at least 266 species of birds in the sanctuary, including critically endangered Indian white-rumped vulture and long-billed vulture. \n");
        content.add("Siruvani dam is a dam in Palakkad District, Kerala located 46 km away from Palakkad town. This dam constructed across the Siruvani River, is for supplying drinking water to the city of Coimbatore in Tamil Nadu. The dam is surrounded by reserve forests. Muthikulam hill is situated on the eastern side of the dam. There is a natural waterfall in the hill. The waterfalls and the Dam are big tourist attractions. The famous 150-year-old Pattiyar Bungalow is on the banks of the Siruvani Reservoir. An agreement was executed in August 1973 between the state Governments for drinking water supply to Coimbatore town and neighboring areas from the Siruvani Dam. The location being in the state of Kerala, the project was executed by the Kerala Public Works Department utilizing the funds made available by the Tamil Nadu Government.");
        content.add("Thirumoorthy Temple is situated at the foot of the Thirumoorthy hills or Thirumoorthy hills adjoining the Thirumoorthy dam. The scenic beauty of the Anaimalai hill range of Western Ghats includes the cascading water to the Thirumoorthy reservoir from the Panchalingam Falls. A perennial stream flows by the side of the Sri Amanalingeswarar temple. The presiding deity is called Amanalingeswarar.  It is also believed that Jain priests or Samanar lived in the hills when Jainism flourished in Tamil Nadu. The huge rock which is worshiped as Thirumoorthy has a sculpture of a Jain priest. A popular belief is that this rock rolled down from the hills few centuries back during a flood. This is supported by the fact that sculpture is carved upside down on rock.\n");
        content.add("Vaidehi Falls is a waterfall situated in the outskirts of Coimbatore city about 35 km (22 mi) from Coimbatore. The nearest village is Narasipuram. This waterfall used to be called \"Tholayira Murthi Kandi\", in Tamil Tholayiram stands for the number nine hundred, word Murthy has several interpretations, one is The Lord, another means Manifestation. Kandi is the word for (water) fall. The waterfall derives the present name after the movie \"Vaithegi Kathirunthal\" by director R. Sundarrajan. The location is now a popular tourist spot in the City of Coimbatore. It is not well connected to transport facilities. Nowadays visitors are not allowed in order to protect wildlife which is abundant in that area.\n");
        content.add("valparai is a Taluk and hill station in the Coimbatore district of Tamil Nadu, India. It is located 3,500 feet (1,100 m) above sea level on the Anaimalai Hills range of the Western Ghats, at a distance of 100 kilometers (62 mi) from Coimbatore and 65 kilometers (40 mi) from Pollachi. There are 40 hairpin bends on the way up to valparai from Azhiyar. While major portions of the land are owned by private tea companies, large forest areas continue to be out of bounds.  As of 2011, the town had a population of 70,859.  valparai is a mid-elevation hill station (Ootacamund is considerably higher). The tea plantations are surrounded by evergreen forest. The region is also a rich elephant tract and is known to have many leopards.  The drive to the town from Pollachi passes through the Indira Gandhi Wildlife Sanctuary noted for elephants, boars, lion-tailed macaques, gaur, spotted deer, sambar, and giant squirrels. The area is also rich in birds, including the great hornbill. Water bodies at Monkey Falls and Aliyar Dam are also seen en route. valparai receives among the highest rainfall in the region during the monsoons (around June).\n");

        image.add("azhiyar_dam");
        image.add("black_thunder_theme_park");
        image.add("kodiveri_dam");
        image.add("kovai_kondattam");
        image.add("mudhumalai_tiger_reserve");
        image.add("siruvani");
        image.add("thirumoorthy_hills");
        image.add("vaidehi_falls");
        image.add("valparai");

        obj.setPlcList(hotels);
        obj.setLocList(location);
        obj.setContList(content);
        obj.setImgList(image);


        Intent next = new Intent(this,placesLoc.class);
        next.putExtra("plobj", obj);
        startActivity(next);
    }
}
